# P74Y
Discord music bot made for testing discord-ytdl-core. Supports filters like bassboost, nightcore, echo, vaporwave etc.

# Note
This bot is absolute garbage. Use it if u wanna...
I made this bot to test my **[discord-ytdl-core](https://npmjs.com/package/discord-ytdl-core)** module.

# Features
- Filters can be changed while playing
- Clean audio

# Audio Filters Available
- bassboost
- echo
- nightcore
- vaporwave

# Join my discord server
**[https://discord.gg/uqB8kxh](https://discord.gg/uqB8kxh)**
