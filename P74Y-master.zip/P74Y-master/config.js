module.exports = {
  token: "BOT_TOKEN",
  youtube: "YOUTUBE_API_KEY",
  admin: ["OWNER_ID"],
  debug: false,
  logger: {
    id: "WEBHOOK_ID",
    token: "WEBHOOK_TOKEN"
  }
};
